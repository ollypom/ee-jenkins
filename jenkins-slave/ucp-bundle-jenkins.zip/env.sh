export DOCKER_TLS_VERIFY=1
export DOCKER_CERT_PATH="$(pwd)"
export DOCKER_HOST=tcp://52.56.242.202:443
#
# Bundle for user jenkins
# UCP Instance ID G63N:C5MQ:NNXD:WN6C:6MD3:HH74:VHQL:IY7V:R3QT:KNBB:EKHW:A4E3
#
# This admin cert will also work directly against Swarm and the individual
# engine proxies for troubleshooting.  After sourcing this env file, use
# "docker info" to discover the location of Swarm managers and engines.
# and use the --host option to override $DOCKER_HOST
#
# Run this command from within this directory to configure your shell:
# eval $(<env.sh)
